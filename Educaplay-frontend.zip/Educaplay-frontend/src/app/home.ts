import { Component } from '@angular/core';
import { Router } from '@angular/router'; 

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [],
  templateUrl: './home.html',
  styleUrl: './app.css'
})
export class HomeComponent {
  animando = false;

  constructor(private router: Router) {}

  iniciarComAnimacao() {
    this.animando = true;
    setTimeout(() => {
      this.router.navigate(['/selecao-perfil']);
    }, 800);
  }
}