import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-login-responsavel',
  standalone: true,
  imports: [RouterLink],
  templateUrl: './login-responsavel.html'
})
export class LoginResponsavelComponent {}