import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-login-infantil',
  standalone: true,
  imports: [RouterLink],
  templateUrl: './login-infantil.html'
})
export class LoginInfantilComponent {}