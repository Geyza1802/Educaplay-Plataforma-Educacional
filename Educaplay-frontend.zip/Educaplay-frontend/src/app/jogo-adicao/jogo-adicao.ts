import { Component, OnInit, computed, signal } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { AuthService } from '../services/auth.service';
import { DesafioService } from '../services/desafio.service';
import { SimboloComponent } from '../simbolo/simbolo';

@Component({
  selector: 'app-jogo-adicao',
  standalone: true,
  imports: [RouterLink, SimboloComponent],
  templateUrl: './jogo-adicao.html',
  styleUrl: './jogo-adicao.css'
})
export class JogoAdicaoComponent implements OnInit {
  nomeCrianca = signal('');
  numeroA = signal(0);
  numeroB = signal(0);
  opcoes = signal<number[]>([]);
  acertos = signal(0);
  erros = signal(0);
  resultado = signal<'acertou' | 'errou' | null>(null);
  respostaEscolhida = signal<number | null>(null);
  aviso = signal('');

  respostaCerta = computed(() => this.numeroA() + this.numeroB());

  private idPerfil = 0;

  constructor(
    private authService: AuthService,
    private desafioService: DesafioService,
    private router: Router
  ) {}

  ngOnInit() {
    const perfil = this.authService.getPerfilInfantilAtual();
    if (!perfil) {
      this.router.navigate(['/login-infantil']);
      return;
    }
    this.idPerfil = perfil.idPerfil;
    this.nomeCrianca.set(perfil.nome);
    this.novaConta();
  }

  novaConta() {
    const a = this.sortear(1, 9);
    const b = this.sortear(1, 9);
    const certa = a + b;

    const escolhas = new Set<number>([certa]);
    while (escolhas.size < 3) {
      const candidata = certa + this.sortear(-3, 3);
      if (candidata >= 0) {
        escolhas.add(candidata);
      }
    }

    this.numeroA.set(a);
    this.numeroB.set(b);
    this.opcoes.set([...escolhas].sort(() => Math.random() - 0.5));
    this.resultado.set(null);
    this.respostaEscolhida.set(null);
    this.aviso.set('');
  }

  responder(valor: number) {
    if (this.resultado() !== null) {
      return;
    }

    const acertou = valor === this.respostaCerta();
    this.respostaEscolhida.set(valor);
    this.resultado.set(acertou ? 'acertou' : 'errou');

    if (acertou) {
      this.acertos.update(n => n + 1);
    } else {
      this.erros.update(n => n + 1);
    }

    this.desafioService
      .registrarDesafio(this.idPerfil, 'adicao', acertou, acertou ? 10 : 0)
      .subscribe({
        error: () => {
          this.aviso.set('Não consegui salvar essa resposta. Verifique se o backend está ligado.');
        }
      });

    setTimeout(() => this.novaConta(), 1600);
  }

  private sortear(minimo: number, maximo: number): number {
    return Math.floor(Math.random() * (maximo - minimo + 1)) + minimo;
  }
}