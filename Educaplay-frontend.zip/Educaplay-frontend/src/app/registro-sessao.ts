import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-registro-sessao',
  standalone: true,
  imports: [RouterLink],
  templateUrl: './registro-sessao.html',
  styleUrl: './registro-sessao.css'
})
export class RegistroSessaoComponent {}