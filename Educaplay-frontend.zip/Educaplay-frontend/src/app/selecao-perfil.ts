import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-selecao-perfil',
  standalone: true,
  imports: [RouterLink],
  templateUrl: './selecao-perfil.html',
  styleUrl: './selecao-perfil.css'
})
export class SelecaoPerfilComponent {}