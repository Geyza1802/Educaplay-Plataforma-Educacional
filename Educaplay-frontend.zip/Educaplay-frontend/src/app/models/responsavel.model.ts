export interface Responsavel {
  idResponsavel: number;
  nome: string;
  email: string;
  senhaHash: string;
  pinSeguranca: string;
}