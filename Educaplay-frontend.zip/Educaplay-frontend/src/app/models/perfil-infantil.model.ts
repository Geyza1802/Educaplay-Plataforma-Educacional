export interface PerfilInfantil {
  idPerfil: number;
  nome: string;
  dataNascimento: Date;
  faixaEtaria: string;
  saldoEstrelas: number;
}