export interface ProgressoMatematica {
  idProgresso: number;
  nivelDificuldade: string;
  operacaoAtual: string;
  totalAcertos: number;
  pontuacaoTotal: number;
}