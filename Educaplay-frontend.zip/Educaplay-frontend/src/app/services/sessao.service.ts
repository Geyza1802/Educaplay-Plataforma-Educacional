import { Injectable } from '@angular/core';
import { RegistroSessao } from '../models/registro-sessao.model';

@Injectable({
  providedIn: 'root'
})
export class SessaoService {
  private sessaoAtiva: RegistroSessao | null = null;
  private timer: any;

  iniciarSessao(): void {
    this.sessaoAtiva = {
      idSessao: Date.now(),
      dataInicio: new Date(),
      tempoUtilizadoSeg: 0,
      bloqueouPorTimer: false
    };

    this.timer = setInterval(() => {
      if (this.sessaoAtiva) {
        this.sessaoAtiva.tempoUtilizadoSeg++;
      }
    }, 1000);
  }

  verificarLimite(limiteSegundos: number): boolean {
    if (this.sessaoAtiva && this.sessaoAtiva.tempoUtilizadoSeg >= limiteSegundos) {
      this.sessaoAtiva.bloqueouPorTimer = true;
      this.pararSessao();
      return true;
    }
    return false;
  }

  pararSessao(): void {
    if (this.timer) {
      clearInterval(this.timer);
    }
  }

  getSessao(): RegistroSessao | null {
    return this.sessaoAtiva;
  }
}