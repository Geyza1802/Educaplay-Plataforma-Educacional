import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Relatorio, PerfilResumo } from '../models/relatorio.model';
import { API_URL } from './api.config';

@Injectable({
  providedIn: 'root'
})
export class RelatorioService {
  constructor(private http: HttpClient) {}


  listarPerfis(idResponsavel: number): Observable<PerfilResumo[]> {
    return this.http.get<PerfilResumo[]>(`${API_URL}/responsaveis/${idResponsavel}/perfis`);
  }


  buscarRelatorio(idPerfil: number): Observable<Relatorio> {
    return this.http.get<Relatorio>(`${API_URL}/perfis/${idPerfil}/relatorio`);
  }
}