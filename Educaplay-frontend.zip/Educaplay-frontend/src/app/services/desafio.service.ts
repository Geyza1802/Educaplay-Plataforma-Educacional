import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { API_URL } from './api.config';

@Injectable({
  providedIn: 'root'
})
export class DesafioService {
  constructor(private http: HttpClient) {}

  registrarDesafio(
    idPerfil: number,
    operacao: string,
    acertou: boolean,
    pontos: number
  ): Observable<unknown> {
    return this.http.post(`${API_URL}/perfis/${idPerfil}/desafios`, {
      operacao,
      acertou,
      pontos
    });
  }
}