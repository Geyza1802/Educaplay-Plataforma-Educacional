import { Routes } from '@angular/router';
import { HomeComponent } from './home/home';
import { SelecaoPerfilComponent } from './selecao-perfil/selecao-perfil';
import { LoginInfantilComponent } from './login-infantil/login-infantil';
import { LoginResponsavelComponent } from './login-responsavel/login-responsavel';
import { RegistroSessaoComponent } from './registro-sessao/registro-sessao';

export const routes: Routes = [

  { path: '', component: HomeComponent, pathMatch: 'full' },
  { path: 'home', component: HomeComponent },
  { path: 'selecao-perfil', component: SelecaoPerfilComponent },
  { path: 'login-infantil', component: LoginInfantilComponent },
  { path: 'login-responsavel', component: LoginResponsavelComponent },
  { path: 'registro-sessao', component: RegistroSessaoComponent },
  { path: '**', redirectTo: '' }
];