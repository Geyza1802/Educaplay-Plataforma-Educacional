import { Routes } from '@angular/router';
import { HomeComponent } from './home';
import { SelecaoPerfilComponent } from './selecao-perfil';
import { LoginInfantilComponent } from './login-infantil';
import { LoginResponsavelComponent } from './login-responsavel';
import { JogosMenuComponent } from './jogos-menu';
import { RegistroSessaoComponent } from './registro-sessao';

export const routes: Routes = [
  { path: '', component: HomeComponent },
  { path: 'selecao-perfil', component: SelecaoPerfilComponent },
  { path: 'login-infantil', component: LoginInfantilComponent },
  { path: 'login-responsavel', component: LoginResponsavelComponent },
  { path: 'jogos-menu', component: JogosMenuComponent },
  

  { path: 'registro-sessao', component: RegistroSessaoComponent },


  { path: '**', redirectTo: '' }
];