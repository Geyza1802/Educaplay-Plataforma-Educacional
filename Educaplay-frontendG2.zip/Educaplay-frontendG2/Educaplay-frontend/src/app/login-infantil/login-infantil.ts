import { Component } from '@angular/core';
import { RouterLink, Router } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { AuthService } from '../services/auth.service';
import { SessaoService } from '../services/sessao.service';

@Component({
  selector: 'app-login-infantil',
  standalone: true,
  imports: [RouterLink, FormsModule],
  templateUrl: './login-infantil.html'
})
export class LoginInfantilComponent {
  nomeCrianca: string = '';

  constructor(
    private authService: AuthService,
    private sessaoService: SessaoService,
    private router: Router
  ) {}

  aoIniciar() {
    if (this.nomeCrianca.trim()) {
      this.authService.entrarComoCrianca(this.nomeCrianca);
      this.sessaoService.iniciarSessao();
      this.router.navigate(['/registro-sessao']);
    } else {
      alert('Escreve o teu nome ou código para jogarmos!');
    }
  }
}