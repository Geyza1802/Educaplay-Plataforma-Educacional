import { Injectable } from '@angular/core';
import { Responsavel } from '../models/responsavel.model';
import { PerfilInfantil } from '../models/perfil-infantil.model';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private responsavelAtual: Responsavel | null = null;
  private perfilInfantilAtual: PerfilInfantil | null = null;

  // Autenticação do Responsável por PIN
  autenticarResponsavel(email: string, pin: string): boolean {
    if (pin.length === 4) {
      this.responsavelAtual = {
        idResponsavel: 1,
        nome: 'Responsável',
        email: email,
        senhaHash: '',
        pinSeguranca: pin
      };
      return true;
    }
    return false;
  }

  // Seleção do Perfil Infantil
  entrarComoCrianca(nome: string): PerfilInfantil {
    this.perfilInfantilAtual = {
      idPerfil: Date.now(),
      nome: nome,
      dataNascimento: new Date(),
      faixaEtaria: '6-8 anos',
      saldoEstrelas: 10
    };
    return this.perfilInfantilAtual;
  }

  getPerfilInfantilAtual(): PerfilInfantil | null {
    return this.perfilInfantilAtual;
  }

  getResponsavelAtual(): Responsavel | null {
    return this.responsavelAtual;
  }
}