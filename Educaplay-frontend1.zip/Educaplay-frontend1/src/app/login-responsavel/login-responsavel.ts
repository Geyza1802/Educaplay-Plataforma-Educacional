import { Component } from '@angular/core';
import { RouterLink, Router } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { AuthService } from '../services/auth.service';

@Component({
  selector: 'app-login-responsavel',
  standalone: true,
  imports: [RouterLink, FormsModule],
  templateUrl: './login-responsavel.html',
  styleUrl: './login-responsavel.css'
})
export class LoginResponsavelComponent {
  email: string = '';
  senha: string = '';
  pinSeguranca: string = '';

  constructor(
    private authService: AuthService,
    private router: Router
  ) {}

  aoEntrar() {
    if (!this.email || !this.senha || !this.pinSeguranca) {
      alert('Por favor, preencha todos os campos!');
      return;
    }

    const sucesso = this.authService.autenticarResponsavel(this.email, this.pinSeguranca);

    if (sucesso) {
      alert('Acesso concedido com sucesso!');
      this.router.navigate(['/selecao-perfil']);
    } else {
      alert('PIN inválido! Digite um PIN com 4 dígitos.');
    }
  }
}