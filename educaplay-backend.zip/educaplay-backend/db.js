// Usa o SQLite que já vem dentro do Node (não precisa instalar nada extra)
const { DatabaseSync } = require('node:sqlite');

// Cria (ou abre) o arquivo do banco
const db = new DatabaseSync('educaplay.db');

// Cria as tabelas do diagrama de classes, se ainda não existirem
db.exec(`
  CREATE TABLE IF NOT EXISTS responsavel (
    id_responsavel INTEGER PRIMARY KEY AUTOINCREMENT,
    nome           TEXT NOT NULL,
    email          TEXT NOT NULL UNIQUE,
    senha_hash     TEXT NOT NULL,
    pin_seguranca  TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS perfil_infantil (
    id_perfil       INTEGER PRIMARY KEY AUTOINCREMENT,
    id_responsavel  INTEGER REFERENCES responsavel(id_responsavel),
    nome            TEXT NOT NULL,
    data_nascimento TEXT,
    faixa_etaria    TEXT NOT NULL DEFAULT '6-8 anos',
    saldo_estrelas  INTEGER NOT NULL DEFAULT 0
  );

  CREATE TABLE IF NOT EXISTS registro_sessao (
    id_sessao           INTEGER PRIMARY KEY AUTOINCREMENT,
    id_perfil           INTEGER NOT NULL REFERENCES perfil_infantil(id_perfil),
    data_inicio         TEXT NOT NULL,
    tempo_utilizado_seg INTEGER NOT NULL DEFAULT 0,
    bloqueou_por_timer  INTEGER NOT NULL DEFAULT 0
  );

  CREATE TABLE IF NOT EXISTS progresso_matematica (
    id_progresso      INTEGER PRIMARY KEY AUTOINCREMENT,
    id_perfil         INTEGER NOT NULL UNIQUE REFERENCES perfil_infantil(id_perfil),
    nivel_dificuldade TEXT NOT NULL DEFAULT 'Fácil',
    operacao_atual    TEXT NOT NULL DEFAULT 'adicao',
    total_acertos     INTEGER NOT NULL DEFAULT 0,
    pontuacao_total   INTEGER NOT NULL DEFAULT 0
  );

  CREATE TABLE IF NOT EXISTS desafio (
    id_desafio INTEGER PRIMARY KEY AUTOINCREMENT,
    id_perfil  INTEGER NOT NULL REFERENCES perfil_infantil(id_perfil),
    operacao   TEXT NOT NULL,
    acertou    INTEGER NOT NULL,
    pontos     INTEGER NOT NULL DEFAULT 0,
    data       TEXT NOT NULL
  );
`);

module.exports = db;
