const express = require('express');
const bcrypt = require('bcryptjs');
const db = require('./db');

const app = express();
app.use(express.json());

const LIMITE_DIARIO_SEG = 40 * 60; // 40 minutos por dia

// Soma o tempo das outras sessões do perfil no dia de hoje
function tempoUsadoHoje(idPerfil, idSessaoAtual) {
  const linha = db
    .prepare(`
      SELECT COALESCE(SUM(tempo_utilizado_seg), 0) AS total
      FROM registro_sessao
      WHERE id_perfil = ?
        AND id_sessao <> ?
        AND date(data_inicio, 'localtime') = date('now', 'localtime')
    `)
    .get(idPerfil, idSessaoAtual);
  return linha.total;
}


app.get('/', (req, res) => {
  res.send('Oi! v2 - O backend do EducaPlay está funcionando!');
});

// Cadastro do responsável
app.post('/api/responsaveis', (req, res) => {
  const { nome, email, senha, pin } = req.body;

  if (!nome || !email || !senha || !/^\d{4}$/.test(pin)) {
    return res.status(400).json({ erro: 'Informe nome, e-mail, senha e um PIN de 4 dígitos.' });
  }

  const senhaHash = bcrypt.hashSync(senha, 10);
  const pinHash = bcrypt.hashSync(pin, 10);

  try {
    const resultado = db
      .prepare('INSERT INTO responsavel (nome, email, senha_hash, pin_seguranca) VALUES (?, ?, ?, ?)')
      .run(nome, email.toLowerCase(), senhaHash, pinHash);

    res.status(201).json({ idResponsavel: resultado.lastInsertRowid, nome, email });
  } catch (erro) {
    res.status(409).json({ erro: 'Este e-mail já está cadastrado.' });
  }
});

// Login do responsável
app.post('/api/responsaveis/login', (req, res) => {
  const { email, senha, pin } = req.body;

  const responsavel = db
    .prepare('SELECT * FROM responsavel WHERE email = ?')
    .get((email || '').toLowerCase());

  const dadosCorretos =
    responsavel &&
    bcrypt.compareSync(senha || '', responsavel.senha_hash) &&
    bcrypt.compareSync(pin || '', responsavel.pin_seguranca);

  if (!dadosCorretos) {
    return res.status(401).json({ erro: 'E-mail, senha ou PIN incorretos.' });
  }

  res.json({
    idResponsavel: responsavel.id_responsavel,
    nome: responsavel.nome,
    email: responsavel.email
  });
});

// A criança entra só com o nome: achamos o perfil ou criamos um novo
app.post('/api/perfis/entrar', (req, res) => {
  const nome = ((req.body && req.body.nome) || '').trim();

  if (!nome) {
    return res.status(400).json({ erro: 'Escreva o seu nome para jogarmos!' });
  }

  let perfil = db
    .prepare('SELECT * FROM perfil_infantil WHERE lower(nome) = lower(?)')
    .get(nome);

  if (!perfil) {
    // Ainda não existe tela para o responsável cadastrar a criança,
    // então o perfil novo fica ligado ao primeiro responsável cadastrado
    const responsavel = db
      .prepare('SELECT id_responsavel FROM responsavel ORDER BY id_responsavel LIMIT 1')
      .get();

    const resultado = db
      .prepare('INSERT INTO perfil_infantil (id_responsavel, nome) VALUES (?, ?)')
      .run(responsavel ? responsavel.id_responsavel : null, nome);

    perfil = db
      .prepare('SELECT * FROM perfil_infantil WHERE id_perfil = ?')
      .get(resultado.lastInsertRowid);
  }

  res.json({
    idPerfil: perfil.id_perfil,
    nome: perfil.nome,
    faixaEtaria: perfil.faixa_etaria,
    saldoEstrelas: perfil.saldo_estrelas
  });
});

// Início de uma sessão de jogo
app.post('/api/sessoes', (req, res) => {
  const idPerfil = Number(req.body && req.body.idPerfil);

  const perfil = db
    .prepare('SELECT 1 FROM perfil_infantil WHERE id_perfil = ?')
    .get(idPerfil);

  if (!perfil) {
    return res.status(404).json({ erro: 'Perfil não encontrado.' });
  }

  const resultado = db
    .prepare('INSERT INTO registro_sessao (id_perfil, data_inicio) VALUES (?, ?)')
    .run(idPerfil, new Date().toISOString());

  res.status(201).json({
    idSessao: resultado.lastInsertRowid,
    idPerfil,
    tempoUtilizadoSeg: 0
  });
});

// Atualiza o tempo de uma sessão e verifica o limite diário
app.put('/api/sessoes/:id', (req, res) => {
  const sessao = db
    .prepare('SELECT * FROM registro_sessao WHERE id_sessao = ?')
    .get(req.params.id);

  if (!sessao) {
    return res.status(404).json({ erro: 'Sessão não encontrada.' });
  }

  // O tempo nunca diminui: pegamos o maior entre o salvo e o enviado
  const enviado = Math.floor(Number(req.body && req.body.tempoUtilizadoSeg) || 0);
  const tempo = Math.max(sessao.tempo_utilizado_seg, enviado);

  const totalHoje = tempoUsadoHoje(sessao.id_perfil, sessao.id_sessao) + tempo;
  const bloqueou = totalHoje >= LIMITE_DIARIO_SEG ? 1 : sessao.bloqueou_por_timer;

  db.prepare('UPDATE registro_sessao SET tempo_utilizado_seg = ?, bloqueou_por_timer = ? WHERE id_sessao = ?')
    .run(tempo, bloqueou, sessao.id_sessao);

  res.json({
    idSessao: sessao.id_sessao,
    tempoUtilizadoSeg: tempo,
    bloqueouPorTimer: bloqueou === 1,
    usadoHojeSeg: totalHoje,
    limiteDiarioSeg: LIMITE_DIARIO_SEG
  });
});


app.listen(3000, () => {
  console.log('Servidor rodando em http://localhost:3000');
});